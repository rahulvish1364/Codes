#include <iostream>
using namespace std;

void main(){
	cout<<"1. C++ Complete reference - HerbertSchild"<<endl;
	cout<<"2. C++ Primer or C++ Object Model by Stanley Lippman"<<endl;
	cout<<"3. Effective C++ - Scott Meyers"<<endl;
	cout<<"4. More Effective C++ - Scott Meyers"<<endl;
	cout<<"5. Efficient C++ - Scott Meyers"<<endl;
	cout<<"6. More Efficient C++ - Scott Meyers"<<endl;	
	cout<<"7. Effective STL - Scott Meyers"<<endl;
	cout<<"8. Books by Bjarne StrouStrup"<<endl;
	cout<<"URL's: "<<endl;
	cout<<" cppreference.org"<<endl;
	cout<<" cplusplus.org"<<endl;
}